const formulario = document.getElementById("wordForm");
const resultado = document.getElementById("resultado");
const historia = document.getElementById("historia");
const reiniciar = document.getElementById("reiniciar");

formulario.addEventListener("submit", function(event) {
    event.preventDefault();

    const palabra1 = document.getElementById("palabra1").value.trim();
    const palabra2 = document.getElementById("palabra2").value.trim();
    const palabra3 = document.getElementById("palabra3").value.trim();
    const palabra4 = document.getElementById("palabra4").value.trim();

    const texto = `Hace mucho tiempo, en una lejanísima ciénaga, vivía un feroz ${palabra1} llamado Shrek.

Un día, su soledad se ve interrumpida por una invasión de ${palabra2}. Hay ratoncitos ciegos en su comida, un enorme y malísimo lobo en su cama, tres ${palabra3} sin hogar y otros seres que han sido deportados de Duloc por el malvado Lord Farquaad.

Para salvar su territorio, Shrek hace un pacto con Farquaad y emprende viaje para conseguir que la bella princesa ${palabra4} acceda a ser la novia del Lord.

En tan importante misión le acompaña un divertido burro, dispuesto a hacer cualquier cosa por Shrek: todo, menos guardar silencio.`;

    historia.textContent = texto;
    resultado.hidden = false;

    resultado.scrollIntoView({
        behavior: "smooth",
        block: "start"
    });
});

reiniciar.addEventListener("click", function() {
    formulario.reset();
    resultado.hidden = true;

    formulario.scrollIntoView({
        behavior: "smooth",
        block: "start"
    });
});